# Bay Geo Intermediate Python Course Material

The zip folder above contains all of the material for BayGeo's Intermediate Python Course

To download the repository click the green code button then -> download zip from the drop down
<a href="https://lh3.googleusercontent.com/xfBYEMIpkgUNsuRVjjDcny2WrWmrwpjk4IwJ9oD01eK_ReJMZWMAMXWfvG4vneT7cI4eV-wgRIikk15YGjU4c6WiW27Z08fgMYprF5modatGxIpeIubniIVLNsrysN1KFZh4fct3PQ=w2400?source=screenshot.guru"> <img src="https://lh3.googleusercontent.com/xfBYEMIpkgUNsuRVjjDcny2WrWmrwpjk4IwJ9oD01eK_ReJMZWMAMXWfvG4vneT7cI4eV-wgRIikk15YGjU4c6WiW27Z08fgMYprF5modatGxIpeIubniIVLNsrysN1KFZh4fct3PQ=w600-h315-p-k" /> </a>

After downloading, unzip the folder and save it somewhere easy to get to on your computer, I recommend your documents folder.
