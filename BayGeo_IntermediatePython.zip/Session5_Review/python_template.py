import os


def get_unique_file_extensions(in_folder: str):
    """Returns a set containing all of the unique 
    extensions found within the users input folder path.

    Args:
        in_folder (string): folder path
    """
    file_ext_list = []

    for file in os.listdir(in_folder):
        full_file_path = os.path.join(in_folder, file)
        if os.path.isfile(full_file_path):
            ext = os.path.splitext(file)[1]
            file_ext_list.append(ext)

    return set(file_ext_list)


def print_text(in_text: str):
    """Just prints the input text

    Args:
        in_text (str): string to print
    """
    print(in_text)


if __name__ == '__main__':
    folder_path = r'C:\Users\Eric\Desktop\temp_local'

    my_file_extensions = get_unique_file_extensions(folder_path)

    print(f'Here are the unique file extensions within the folder: {my_file_extensions}')

