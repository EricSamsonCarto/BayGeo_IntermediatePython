# this file uses a cutom function created in a completely different python file using import!
from python_template import get_unique_file_extensions

folder_path = r'C:\Users\Eric\Desktop\temp_local'
my_file_extensions = get_unique_file_extensions(folder_path)

print(f'Here are the unique file extensions within the folder: {my_file_extensions}')