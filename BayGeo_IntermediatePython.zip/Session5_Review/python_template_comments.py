# This represents a python template file! 
# the below is the typical structure of a python file

# the first step is to always import the needed modules
import os

# place all of your created functions here
def get_unique_file_extensions(in_folder: str):
    """Returns a set containing all of the unique 
    extensions found within the users input folder path.

    Args:
        in_folder (string): folder path
    """
    file_ext_list = []

    for file in os.listdir(in_folder):
        full_file_path = os.path.join(in_folder, file)
        if os.path.isfile(full_file_path):
            ext = os.path.splitext(file)[1]
            file_ext_list.append(ext)

    return set(file_ext_list)


def print_text(in_text: str): # two indents always seperate functions
    """Just prints the input text

    Args:
        in_text (str): string to print
    """
    print(in_text)

# the below line tells python to run what is indented below when the user specifies too.
# this ensures that code will not be imported or ran when importing the functions to other python files.
# for an example, see the import_create_functions.py file
if __name__ == '__main__':
    # below this line and with one indentation is the actual script
    # that runs what we need and utilizes the functions that we defined
    # at the top of the file
    folder_path = r'C:\Users\Eric\Desktop\temp_local'

    unique_file_extensions = get_unique_file_extensions(folder_path)

    print(f'Here are the unique file extensions within the folder: {unique_file_extensions}')

